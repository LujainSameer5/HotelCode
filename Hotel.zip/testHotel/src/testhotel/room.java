/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhotel;

import java.util.ArrayList;

/**
 *
 * @author لجين
 */
public class room implements discount {
    
    private int numberRoom;// number room is booking 
    private String type; // type of room
    private double price; // price of room
    private int days; // number of days of bookibg

    public room(int numberRoom, String type, double price, int days) {
        this.numberRoom = numberRoom;
        this.type = type;
        this.price = price;
        this.days = days;
    }

   public int getNumberRoom() {
        return numberRoom;
    }

    public void setNumberRoom(int numberRoom) {
        this.numberRoom = numberRoom;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }
     
    
    @Override
    public double calculatepriceAfterDiscount(){ // metod to calcualst a discount
   double discount_amount=0.0;
   if(days>=5){ /*The offer is as follows: if you book 5 days or more, there will be discount for you */
    if(type=="suite"){
        discount_amount = price*suite_Discount;
        return discount_amount; 
        
    } 
    else if(type=="deluxe"){
        discount_amount = price*deluxe_Discount;
       
        return discount_amount;
    }
    else if(type=="standard"){
        discount_amount= price*standard_Discount;
      
        return discount_amount;
    }
   }
  
   return price; 
   }

    @Override
    public String toString() {
        return super.toString()+ "\n\t" +"Reserved room number: " + numberRoom + "\n\tType of room: " + type + "\n\tThe price After Discount if you book more 5 days: " + calculatepriceAfterDiscount() + "\n\tThe Number of days of reservation: " + days;
    } // print info of room is booking
    
}
