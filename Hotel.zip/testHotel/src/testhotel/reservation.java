/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhotel;
import java.util.*;
/**
 *
 * @author لجين
 */
public class reservation extends person {
    

 
  protected room Room;
 
    public reservation( String name, int ID, room Room,Recption_Employees Employees) {
        super(name, ID, Employees);
        this.Room = Room;
    }

    public room getRoom() {
        return Room;
    }

    public void setRoom(room Room) {
        this.Room = Room;
    }

  
 

    public Recption_Employees getEmployees() {
        return Employees;
    }

    public void setEmployees(Recption_Employees Employees) {
        this.Employees = Employees;
    }

    

  
   
     public void printbookOf() {
         System.out.println("\n\n\t*****RESERVATION INFORMATION*****\n\n");
        System.out.println("\nGuest's name: "+ getName() +", ID number: "+getID()+", his order:"+ Room);
         
        System.out.print("\nServed by: " + Employees.getNameRM()+"\n" );
    }
    
}