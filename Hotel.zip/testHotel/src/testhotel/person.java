/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhotel;
import java.util.*;
/**
 *
 * @author لجين
 */
public class person implements Comparable<person> {
    
    private String name;// name of a guests
    private int ID; // id of a guests
    protected Recption_Employees Employees;
   

    public person(String name, int ID, Recption_Employees Employees) {
        this.name = name;
        this.ID = ID;
        this.Employees = Employees;
        
    }

    public Recption_Employees getEmployees() {
        return Employees;
    }

    public void setEmployees(Recption_Employees Employees) {
        this.Employees = Employees;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

   
    
    
    @Override
    public int compareTo(person o) {

        if( this.ID > o.ID)
            return 1;
        else if (this.ID < o.ID)
            return -1;
        else
            return 0;
    }

    
    
    
    @Override
    public String toString() {
        return super.toString()+"\n--------------------------------------\n\t***RESERVATION***\n\tName of Guest: " + name + "\n\tID: " + ID;
    } // to print info of Guests

   

    

    
    
}
