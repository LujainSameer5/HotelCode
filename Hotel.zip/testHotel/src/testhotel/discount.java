/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhotel;

/**
 *
 * @author لجين
 */
public interface discount {
    
    public static final double suite_Discount = 0.50; // you get a discount of suite room if you book 5 days or more.
    public static final double deluxe_Discount = 0.30; // you get a discount of deluxe room if you book 5 days or more.
     public static final double standard_Discount = 0.25; // you get a discount of standard room if you book 5 days or more.
    
    public String getType();
    public void setType(String type);

    public double getPrice();
    public void setPrice(double price);
    
     public abstract double calculatepriceAfterDiscount(); // metod to calcualst a discount
}

