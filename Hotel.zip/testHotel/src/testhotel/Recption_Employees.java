/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhotel;
import java.util.*;
/**
 *
 * @author لجين
 */
public class Recption_Employees implements Comparable<Recption_Employees> {
    private String nameRM; //name of Employees
    private int ID_RM; // id of Employees
    private String email;
    private double salary;

    public Recption_Employees(String nameRM, int ID_RM, String email, double salary) {
        this.nameRM = nameRM;
        this.ID_RM = ID_RM;
        this.email = email;
        this.salary = salary;
    }

    public String getNameRM() {
        return nameRM;
    }

    public void setNameRM(String nameRM) {
        this.nameRM = nameRM;
    }

    public int getID_RM() {
        return ID_RM;
    }

    public void setID_RM(int ID_RM) {
        this.ID_RM = ID_RM;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    
    
    
     @Override
     
    public int compareTo(Recption_Employees o) {

        if( this.ID_RM > o.ID_RM)
            return 1;
        else if (this.ID_RM < o.ID_RM)
            return -1;
        else
            return 0;
    }


    @Override
    public String toString() {
        return  "\tName Employee: "+ nameRM + "\t,ID of Employee: " + ID_RM + "\t,Email: "+ email+"\t,Salary: " + salary;
    } // to print a info of Employees.


    
}
