/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhotel;

import java.util.*;

/**
 *
 * @author لجين
 */
public class Hotel{
    private String Name;
    private String Address;
     ArrayList<Recption_Employees> Employees;
     ArrayList<reservation> Guest;
     ArrayList<room> Room;
     
     
    public Hotel(String Name, String Address) {
        this.Name = Name;
        this.Address = Address;
        Employees=new ArrayList<>();
        Guest=new ArrayList<>();
        Room=new ArrayList<>();
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public ArrayList<Recption_Employees> getEmployees() {
        return Employees;
    }

    public void setEmployees(ArrayList<Recption_Employees> Employees) {
        this.Employees = Employees;
    }

    public ArrayList<reservation> getGuest() {
        return Guest;
    }

    public void setGuest(ArrayList<reservation> Guest) {
        this.Guest = Guest;
    }

    public ArrayList<room> getRoom() {
        return Room;
    }

    public void setRoom(ArrayList<room> Room) {
        this.Room = Room;
    }
    
      public void addRoom(room R){
        Room.add(R);
    }
    public void addEmployees(Recption_Employees E){
        Employees.add(E);
    }
   
     public void addGuest(reservation G){
        Guest.add(G);
    }
     
   public void printEmployees() {
        for (Recption_Employees E:Employees)
            System.out.println(E);
    }
 
   public void printbookOf() {
        for (reservation G:Guest)
            System.out.println(G);
    }
 
  
    @Override
    public String toString() {
        return "\t*****Hotel infomations*****\n" + "\tHotel Name is: " + Name.toUpperCase() + "\n\tit's located in " + Address.toUpperCase()+"\n\n";
    }
      
}
   