/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhotel;
import java.util.*;
/**
 *
 * @author لجين
 */
//Lojain Sameer Batuq 
//ID: 439006070
public class TestHotel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Hotel hotel = new Hotel("Roze Hotel","Jeddah-AL-Hmra");
        
        Recption_Employees Em1 = new Recption_Employees("rayan",4786665,"rayan@hotmail.com",3000);
        Recption_Employees Em2 = new Recption_Employees("Ahmad",4786666,"Ahmad@hotmail.com",3000);
        hotel.addEmployees(Em1);
        hotel.addEmployees(Em2);
        
        ArrayList<room> Room= new ArrayList<>();
        room r1= new room(301,"deluxe",6000,6);
        room r2= new room(101,"standard",2800,4);
        room r3= new room(501,"suite",9500,5);
        hotel.addRoom(r1);
        hotel.addRoom(r2);
        hotel.addRoom(r3);
        ArrayList<reservation> resv= new ArrayList<>();
        reservation re1 = new reservation("Sara",1234567,r2,Em1);
        reservation re2 = new reservation("Khalid",1234565,r3,Em1);
        reservation re3 = new reservation("Mohamad",1234567,r1,Em2);
        hotel.addGuest(re1);
        hotel.addGuest(re2);
        hotel.addGuest(re3);
        System.out.println(hotel);
        System.out.println("\tinformation of Employee" +hotel.getName()+"\n");
        hotel.printEmployees();
        System.out.println("\n All reservation of today:- \n");
        re1.printbookOf();
        re2.printbookOf();
        re3.printbookOf();
        
        
    }

    
}
